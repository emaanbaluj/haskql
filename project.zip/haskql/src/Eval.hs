module Eval (eval) where

import CQLParser (ColData (..), ColRow (..), ColRowData (..), Expr (..), FilterQuery (..), Literal, MergeType (..), Operand (..), Operator (..), Query (..), SortOrder (..), Stmt (..), Trim (..), VarName)
import Control.DeepSeq (force)
import Control.Exception (SomeException, evaluate, try)
import Control.Monad.State
  ( MonadIO (liftIO),
    MonadState (get),
    when,
  )
import Data.Char (toLower, toUpper)
import Data.List (nub, sort, sortBy, transpose)
import qualified Data.Map as Map
import Data.Maybe (fromJust)
import Data.Ord (Down (Down), comparing)
import State (addToContext)
import Types (CSVData, CSVRow, CSVState)
import Util (combineRows, convertToCSV, getColFromTable, getRowFromTable, insertAfter, readCSV, replaceWith, safeAccess, setColInTable, setRowInTable, trimString, updateRow, writeToCSV)

eval :: Stmt -> CSVState ()
eval (Update var literals filterQuery) = do
  ctx <- get
  case Map.lookup var ctx of
    Nothing -> liftIO $ putStrLn ("<error> no such table: " ++ var)
    Just table -> do
      filteredTable <- filterResult filterQuery var
      let updatedTable = map (\row -> if row `elem` filteredTable then updateRow row literals else row) table

      addToContext var updatedTable
eval (Access2D var firstAxis firstIdx secondAxis secondIdx output) = do
  ctx <- get
  case Map.lookup var ctx of
    Nothing -> liftIO $ putStrLn ("<error> no such table: " ++ var)
    Just table -> do
      value <- liftIO $ try (evaluate (access2D table firstAxis firstIdx secondAxis secondIdx)) :: CSVState (Either SomeException String)
      case value of
        Left _ -> liftIO $ error (var ++ ".COL(" ++ show firstIdx ++ ").ROW(" ++ show secondIdx ++ ") is out of bounds for table " ++ var)
        Right v -> addToContext output [[v]]
eval (PrintColRow (ColRowData var COL colNum) _ trim) = do
  ctx <- get
  case Map.lookup var ctx of
    Nothing -> liftIO $ putStrLn ("<error> no such table: " ++ var)
    Just table -> do
      columnTry <- liftIO $ try (evaluate (force (map (`safeAccess` (colNum - 1)) table))) :: CSVState (Either SomeException [String])
      column <- case columnTry of
        Left _ -> liftIO $ error (var ++ ".COL(" ++ show colNum ++ ") is out of bounds for table " ++ var)
        Right c -> return c
      trimmed <- case trim of
        TrimTrue -> return (map trimString column)
        TrimFalse -> return column

      liftIO $ putStr (unlines trimmed)
eval (PrintColRow (ColRowData var ROW rowNum) _ trim) = do
  ctx <- get
  case Map.lookup var ctx of
    Nothing -> liftIO $ putStrLn ("<error> no such table: " ++ var)
    Just table -> do
      rowTry <- liftIO $ try (evaluate (force (table `safeAccess` (rowNum - 1)))) :: CSVState (Either SomeException [String])
      row <- case rowTry of
        Left _ -> liftIO $ error (var ++ ".ROW(" ++ show rowNum ++ ") is out of bounds for table " ++ var)
        Right r -> return r
      let trimmed = case trim of
            TrimTrue -> map trimString row
            TrimFalse -> row
      liftIO $ putStr (unwords trimmed)
eval (Transpose input output) = do
  ctx <- get
  case Map.lookup input ctx of
    Nothing -> liftIO $ error ("<error> no such table: " ++ input)
    Just table -> addToContext output (transpose table)
eval (Map expr input output) = do
  ctx <- get
  case Map.lookup input ctx of
    Nothing -> liftIO $ error ("<error> no such table: " ++ input)
    Just rows -> do
      let newRows = map (map (apply expr)) rows
      addToContext output newRows
eval (Write var filePath) = do
  ctx <- get
  case Map.lookup var ctx of
    Nothing -> liftIO $ putStrLn ("<error> no such variable: " ++ var)
    Just table -> liftIO $ writeToCSV table filePath
eval (Import file var) = do
  result <- liftIO $ readCSV file
  addToContext var result
eval (Print var sortOrder trim) = do
  ctx <- get
  let result = Map.lookup var ctx
  liftIO $ putStr $ formatResult result
  where
    formatResult :: Maybe CSVData -> String
    formatResult Nothing = "Variable not found"
    formatResult (Just result) =
      let sortedData = sortData result sortOrder
          trimmedData = trimData sortedData trim
       in convertToCSV trimmedData

    sortData :: CSVData -> SortOrder -> CSVData
    sortData result NO = result
    sortData result ASC = sort result
    sortData result DESC = sortBy (comparing Down) result

    trimData :: CSVData -> Trim -> CSVData
    trimData result TrimTrue = map (map trimString) result
    trimData result TrimFalse = result
eval (Set var queries) = do
  mapM_ (queryHandler var) queries
eval (Insert colrow literals var newVar) = do
  ctx <- get
  case Map.lookup var ctx of
    Nothing -> liftIO $ putStrLn ("<error> no such table: " ++ var)
    Just table -> do
      let newTable = insertRowOrCol colrow table literals
      addToContext newVar newTable

insertRowOrCol :: ColRow -> CSVData -> [Literal] -> CSVData
insertRowOrCol COL table literals =
  let tTable = transpose table
      newTable = tTable ++ [foldl (\acc lit -> if lit == "NULL" then acc ++ [""] else acc ++ [lit]) [] literals]
   in transpose newTable
insertRowOrCol ROW table literals = table ++ [foldl (\acc lit -> if lit == "NULL" then acc ++ [""] else acc ++ [lit]) [] literals]

apply :: Expr -> String -> String
apply (AddN n) s = case reads s of
  [(x, "")] -> show (x + n :: Int)
  _ -> s
apply (SubN n) s = case reads s of
  [(x, "")] -> show (x - n :: Int)
  _ -> s
apply (DivideN n) s = case reads s of
  [(x, "")] -> show (x / n :: Double)
  _ -> s
apply (MultiplyN n) s = case reads s of
  [(x, "")] -> show (x * n :: Double)
  _ -> s
apply (ReplaceWith literal1 literal2) s = if s == literal1 then literal2 else s
apply ToUpper s = map toUpper s
apply ToLower s = map toLower s
apply Not "True" = "False"
apply Not "False" = "True"
apply Not s = s

access2D :: CSVData -> ColRow -> Int -> ColRow -> Int -> String
access2D table COL colIdx ROW rowIdx = (transpose table `safeAccess` (colIdx - 1)) `safeAccess` (rowIdx - 1)
access2D table ROW rowIdx COL colIdx = (table `safeAccess` (rowIdx - 1)) `safeAccess` (colIdx - 1)
access2D _ _ _ _ _ = ""

queryHandler :: VarName -> Query -> CSVState ()
queryHandler var query = do
  ctx <- get
  case query of
    Limit limit varName -> do
      let table = fromJust (Map.lookup varName ctx)
      let limitedData = take limit table
      addToContext var limitedData
    Distinct varName -> do
      let table = fromJust (Map.lookup varName ctx)
      let distinctData = nub table
      addToContext var distinctData
    Union vars -> do
      let tables = map (fromJust . (`Map.lookup` ctx)) vars
      let unionedData = nub $ concat tables
      addToContext var unionedData
    Merge mergeType var1 var2 colNum -> do
      let table1 = fromJust (Map.lookup var1 ctx)
      let table2 = fromJust (Map.lookup var2 ctx)
      let rowPairs = combineRows table1 table2
      filteredRowPairs <- liftIO $ try (evaluate $ force $ filter (\(row1, row2) -> row1 `safeAccess` (colNum - 1) == row2 `safeAccess` (colNum - 1)) rowPairs) :: CSVState (Either SomeException [(CSVRow, CSVRow)])
      case filteredRowPairs of
        Left _ -> liftIO $ error ("Error accessing " ++ var1 ++ " or " ++ var2 ++ " in merge operation. Check index " ++ show colNum ++ " is valid for both tables.")
        Right pairs -> do
          let zippedRowPairs = map (uncurry zip) pairs
          let mergedData = mergeRows mergeType zippedRowPairs
          addToContext var mergedData
      where
        mergeRows :: MergeType -> [[(String, String)]] -> [CSVRow]
        mergeRows LeftMerge = map (map (\(p, q) -> if null p then q else p))
        mergeRows RightMerge = map (map (\(p, q) -> if null q then p else q))
    Filter table filterQuery -> do
      filteredResult <- filterResult filterQuery table
      addToContext var filteredResult
    Zip vars -> do
      let tables = map (fromJust . (`Map.lookup` ctx)) vars
      let emptyTable = replicate (maximum (map length tables)) []
      let result = foldl (zipWith (++)) emptyTable tables
      addToContext var result
    Stack vars -> do
      let tables = map (fromJust . (`Map.lookup` ctx)) vars
      let result = concat tables
      addToContext var result
    Cross vars -> do
      let results = map (fromJust . (`Map.lookup` ctx)) vars
      let result = foldl (\acc row -> [r1 ++ r2 | r1 <- acc, r2 <- row]) [[]] results
      addToContext var result
    Reverse colrow reverseVar -> do
      let table = fromJust (Map.lookup reverseVar ctx)
      let result = reverseRowOrCol colrow table
      addToContext var result
    Complement var1 var2 -> do
      let table1 = fromJust (Map.lookup var1 ctx)
      let table2 = fromJust (Map.lookup var2 ctx)
      let result = filter (`notElem` table2) table1
      addToContext var result
    Get colRows -> do
      tryRows <- liftIO $ try $ evaluate $ force $ transpose $ map rowsFunction colRows :: CSVState (Either SomeException [[String]])
      case tryRows of
        Left _ -> liftIO $ error ("ERROR WITH GET on " ++ var ++ ". Out of bounds")
        Right rows -> do
          let nonEmptyRows =
                foldr
                  (\col acc -> if all (== "") col then acc else col : acc)
                  []
                  rows
          addToContext var nonEmptyRows
      where
        rowsFunction :: ColRowData -> [String]
        rowsFunction (ColRowData table _ colNum) =
          let tableData = Map.lookup table ctx
           in case tableData of
                Nothing -> replicate 100 ""
                Just result -> map (\dat -> dat `safeAccess` (colNum - 1)) result
    Concat (ColRowData table _ colNum) literals -> do
      let tableData = fromJust (Map.lookup table ctx)
      let updatedData = map (\row -> insertAfter row colNum literals) tableData
      let replacedData = map (\row -> let colValue = row `safeAccess` (colNum - 1) in replaceWith "$" colValue row) updatedData
      addToContext var replacedData
    Replace target source -> do
      let targetTable = case target of (ColRowData table _ _) -> table
      let sourceTable = case source of (ColRowData table _ _) -> table

      targetData <- case Map.lookup targetTable ctx of
        Just data' -> return data'
        Nothing -> liftIO (putStrLn $ "Error: Table " ++ targetTable ++ " not found") >> return []

      sourceData <- case Map.lookup sourceTable ctx of
        Just data' -> return data'
        Nothing -> liftIO (putStrLn $ "Error: Table " ++ sourceTable ++ " not found") >> return []

      when (not (null targetData) && not (null sourceData)) $ do
        let (targetType, targetNum) = case target of (ColRowData _ t n) -> (t, n)
        let (sourceType, sourceNum) = case source of (ColRowData _ t n) -> (t, n)

        let dataToCopy = case sourceType of
              COL -> getColFromTable sourceData sourceNum
              ROW -> getRowFromTable sourceData sourceNum

        let updatedData = case targetType of
              COL ->
                setColInTable targetData targetNum dataToCopy
              ROW ->
                setRowInTable targetData targetNum dataToCopy

        addToContext targetTable updatedData
        when (targetTable /= var) $ addToContext var updatedData

reverseRowOrCol :: ColRow -> CSVData -> CSVData
reverseRowOrCol ROW table = map reverse table
reverseRowOrCol COL table = transpose (map reverse (transpose table))

filterResult :: FilterQuery -> VarName -> CSVState CSVData
filterResult (FilterColRowIsNotIn (ColData inputColNum) (ColRowData targetTable _ colNum)) table = do
  ctx <- get
  let targetTableData = fromJust (Map.lookup targetTable ctx)
  let inputTableData = fromJust (Map.lookup table ctx)

  let targetColumns = map (`safeAccess` (colNum - 1)) targetTableData

  return $ filter (\row -> row `safeAccess` (inputColNum - 1) `notElem` targetColumns) inputTableData
filterResult (FilterColRowIsIn (ColData inputColNum) (ColRowData targetTable _ colNum)) table = do
  ctx <- get
  let targetTableData = fromJust (Map.lookup targetTable ctx)
  let inputTableData = fromJust (Map.lookup table ctx)

  let targetColumns = map (`safeAccess` (colNum - 1)) targetTableData

  return $ filter (\row -> row `safeAccess` (inputColNum - 1) `elem` targetColumns) inputTableData
filterResult (FilterColRowIsNotNull (ColData colNum)) table = do
  ctx <- get
  let tableData = fromJust (Map.lookup table ctx)
  return $ filter (\row -> row `safeAccess` (colNum - 1) /= "") tableData
filterResult (FilterColRowIsNull (ColData colNum)) table = do
  ctx <- get
  let tableData = fromJust (Map.lookup table ctx)
  return $ filter (\row -> row `safeAccess` (colNum - 1) == "") tableData
filterResult (FilterColRow (ColData colNum) operator (ColData colNum2)) table = do
  ctx <- get
  let tableData = fromJust (Map.lookup table ctx)
  return $ filter (\row -> filterFunction operator (row `safeAccess` (colNum - 1)) (row `safeAccess` (colNum2 - 1))) tableData
filterResult (FilterColRowOperand (ColData colNum) operator operand) table = do
  ctx <- get
  let tableData = fromJust (Map.lookup table ctx)
  return $ case operand of
    OperandLiteral literal ->
      filter (\row -> filterFunction operator (row `safeAccess` (colNum - 1)) literal) tableData
    OperandNum num ->
      filter (\row -> filterFunction operator (read (row `safeAccess` (colNum - 1)) :: Double) (fromIntegral num)) tableData
    OperandFloat float ->
      filter (\row -> filterFunction operator (read (row `safeAccess` (colNum - 1)) :: Double) (realToFrac float)) tableData
    OperandArity varName ->
      let targetTable = fromJust (Map.lookup varName ctx)
       in filter (\row -> filterFunction operator (read (row `safeAccess` (colNum - 1)) :: Double) (fromIntegral (length $ transpose targetTable))) tableData

filterFunction :: (Ord a) => Operator -> a -> a -> Bool
filterFunction op operand1 operand2 = case op of
  Equal -> operand1 == operand2
  NotEqual -> operand1 /= operand2
  LessThan -> operand1 < operand2
  GreaterThan -> operand1 > operand2
  LessThanOrEqual -> operand1 <= operand2
  GreaterThanOrEqual -> operand1 >= operand2